# Week 6 Task Checklist (AI/ML Internship – Decision Trees & Random Forest)
Deadline: November 13, 2026

## Learning objectives
- [x] Decision Tree: nodes, branches, leaves, classification, Gini, Entropy, overfitting
- [x] Random Forest: ensemble learning, multiple trees, feature importance

## Task 1: Dataset Preparation
- [x] Load dataset (Breast Cancer Wisconsin, same as Week 5)
- [x] Check missing values (0 found)
- [x] Handle missing values (not needed)
- [x] Remove duplicates (0 found)
- [x] Encode categorical variables (not needed, all numeric)
- [x] Select features (30) and target
- [x] Train/test split 80/20 (stratified)

## Task 2: Decision Tree Model
- [x] Create DecisionTreeClassifier
- [x] Train model
- [x] Make predictions
- [x] Accuracy / Precision / Recall / F1
- [x] Visualize tree and explain root/decision nodes/branches/leaves

## Task 3: Random Forest Model
- [x] Create RandomForestClassifier (100 trees)
- [x] Train, predict, evaluate (4 metrics)
- [x] Display feature importance

## Task 4: Compare Three Models
- [x] Comparison table: LR vs DT vs RF (Accuracy, Precision, Recall, F1)
- [x] Highest accuracy: Logistic Regression (0.9825)
- [x] Best F1-score: Logistic Regression (0.9861)
- [x] Chosen model: Random Forest (robustness + low variance) with justification

## Task 5: Visualizations
- [x] Confusion matrix (best model)
- [x] Feature importance chart
- [x] Model comparison bar chart
- [x] 17 extra visualizations included

## Bonus Task
- [x] Vary max_depth / min_samples_split / min_samples_leaf
- [x] Compare results and explain parameter effects

## Submission
- [x] Report (Week6_Report.docx — also exportable to PDF)
- [x] Notebook (Week6_Notebook.ipynb)
- [x] Dataset (breast_cancer_dataset.csv + source note)
- [x] 20 code & output figures (figures/ folder)
- [x] Slides (Week6_Slides.pptx)
- [x] Reflection answers (Reflection_Answers.md)
- [x] LinkedIn post (LinkedIn_Post.md)
