# LinkedIn Post — Week 6 (AI/ML Internship)

Excited to share what I built this week during my AI/ML Internship! 🚀

Week 6 topic: Decision Trees & Random Forest 🌳🌲🌲 — and how they compare to Logistic Regression.

🔍 What I did:
• Prepared the Breast Cancer Diagnostic dataset (missing values, duplicates, encoding, stratified 80/20 split)
• Built and visualized a Decision Tree — and discovered the classic overfitting trap (100% train vs 91% test accuracy!)
• Trained a Random Forest (100 trees) and analyzed feature importance
• Compared all three models head-to-head and tuned hyperparameters (max_depth, min_samples_split, min_samples_leaf)

📊 Results on the held-out test set:
✅ Logistic Regression: 98.25% accuracy
✅ Random Forest: 95.61% accuracy (recall up to 97.2% — only 2 malignant tumors missed!)
⚠️ Single Decision Tree: 91.23% (clearly overfitting)

💡 Key takeaway: no single algorithm is "best" — evaluate on unseen data and choose based on robustness, not just a score on one split. Also, more advanced ≠ automatically better!

Big thanks to my mentors and teammates for the support this week. On to Week 7! 💪

#MachineLearning #AI #DataScience #Internship #Python #ScikitLearn #RandomForest #DecisionTree #LearningByDoing #100DaysOfMLCode

[Attach: confusion matrix, tree visualization, comparison bar chart]
