WEEK 6 SUBMISSION — Decision Trees & Random Forest
==================================================
Contents:
- Week6_Report.docx      -> Full report (Introduction, Dataset, Preprocessing, DT, RF,
                            Evaluation, Confusion Matrix, Feature Importance, Comparison,
                            Bonus tuning, Conclusion). Export to PDF before submitting.
- Week6_Slides.pptx      -> 11 presentation slides
- Week6_Notebook.ipynb   -> All code (Tasks 1-5 + Bonus)
- breast_cancer_dataset.csv -> Dataset
- model_comparison.csv   -> Comparison table values
- figures/               -> 20 output visualizations (evidence screenshots)
- Reflection_Answers.md  -> Answers to the 4 reflection questions
- Task_List.md           -> Full task checklist in English
- LinkedIn_Post.md       -> Ready-to-publish LinkedIn post

Metrics (test set, 114 samples):
Logistic Regression: Acc 0.9825 | Prec 0.9861 | Rec 0.9861 | F1 0.9861
Decision Tree:       Acc 0.9123 | Prec 0.9559 | Rec 0.9028 | F1 0.9286
Random Forest:       Acc 0.9561 | Prec 0.9589 | Rec 0.9722 | F1 0.9655
Chosen model: Random Forest (robustness, low variance, feature importances)
