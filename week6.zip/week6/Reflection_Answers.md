# Week 6 Reflection — Decision Trees & Random Forest

## What did you learn this week?
This week I learned tree-based machine learning algorithms: Decision Trees and Random Forests.
I understood how a Decision Tree works (root node, decision nodes, branches, leaf nodes),
how it chooses splits using Gini Impurity and Entropy, and why an unconstrained tree
overfits the training data. I also learned ensemble learning through Random Forest —
how training many trees on random subsets of rows and features and combining their votes
drastically reduces overfitting and variance, and how it provides feature importance scores.

## Explain your learning in your own words.
A Decision Tree is like a flowchart of yes/no questions. It starts at the root node and
keeps asking "is feature X less than value Y?" until it reaches a leaf that gives the answer.
It picks the question that best separates the classes (lowest Gini/Entropy). If we let it
ask unlimited questions, it memorizes the training data — that's overfitting. A Random
Forest is like asking 100 different doctors instead of one: each doctor (tree) sees a
slightly different sample of patients and symptoms, and the final diagnosis is a vote.
Individual doctors may be wrong, but together they are much more reliable.

## What challenges did you face?
1. The default Decision Tree overfit badly — training accuracy was ~100% while test accuracy was only ~91%.
2. The single tree misclassified 7 malignant tumors as benign (high cost in a medical dataset).
3. Interpreting the visualized tree (it was very deep) was difficult.
4. Surprising result: the simple Logistic Regression from Week 5 beat both tree models on this test split, which forced me to question my assumption that "more advanced = better".

## How did you solve those challenges?
1. Overfitting: tuned max_depth (best at 4), min_samples_split and min_samples_leaf —
   test accuracy improved from 0.9123 to 0.9211 and the tree became smaller and readable.
2. Missed malignant cases: Random Forest improved recall from 0.9028 to 0.9722,
   missing only 2 malignant cases instead of 7.
3. Tree interpretation: limited the plotted depth to the top 3 levels and read the root
   split (worst concave points ≤ 0.142) carefully.
4. Model selection: I learned to trust metrics, not intuition — I compared Accuracy, Precision,
   Recall, F1 and ROC curves on a held-out test set, and chose Random Forest for its
   robustness even though Logistic Regression scored marginally higher on this one split.
